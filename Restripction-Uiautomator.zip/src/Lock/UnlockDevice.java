package Lock;

import uiautomatorApis.Device;
import android.os.RemoteException;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class UnlockDevice extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"UnlockDevice");
	}
	public void testUnlockDevice()
	{
		Device.registerAppCrashWatcher();
		try {
			UiDevice.getInstance().wakeUp();		
			Device.IDLE();
			if(new UiObject(new UiSelector().description("Apps")).exists())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"UnlockDevice");
	}
}
