package MobileData;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class DataOff extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"DataOff");
	}

	public void testDataOff()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			//Device.CLICKBYNAME("More...", true);
			Device.CLICKBYCLASS("android.widget.TextView", 5, true);
			Device.CLICKBYNAME("Mobile networks", true);			
			Device.CHECKBOXONOFF(true, 0);
			Device.SLEEP(5000);			
			if(!Device.CHECKBOXONOFFSTATUS(0))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}	
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"DataOff");
	}
}
