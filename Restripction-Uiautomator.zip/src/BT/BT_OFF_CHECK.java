package BT;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class BT_OFF_CHECK extends UiAutomatorTestCase{
	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"BT_OFF_CHECK");
	}
	
	public void testBTOff()
	{		
		Device.registerAppCrashWatcher();
		Device.SLEEP(5000);
		/*Device.TURNONWIFI();
		Device.IDLE();
		*/
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAME("Bluetooth", true);
			if(!new UiObject(new UiSelector().className("android.widget.Switch")).isChecked())
				new UiObject(new UiSelector().className("android.widget.Switch")).click();
			Device.SLEEP(10000);
			if(!new UiObject(new UiSelector().className("android.widget.Switch")).isChecked())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
		finally
		{
			Device.HOME();
		}
	}
	
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"BT_OFF_CHECK");
	}
}
