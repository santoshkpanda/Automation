package Camera;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class CAMERA_ON extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"CAMERA_ON");
	}
	public void testCameraOn()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Camera");			
			Device.CLICKBYNAME("Next", false);
			Device.CLICKBYNAME("Next", false);
			Device.CLICKBYNAME("Done", false);
			Device.CLICKBYNAME("No thanks", true);
			Device.SLEEP(2000);
			Device.CLICKBYNAME("OK", true);
			if("Shutter".equals(Device.GETDESCBY_CLASS("android.widget.ImageView",1))||
					new UiObject(new UiSelector().resourceId("com.motorola.camera:id/preview_surface")).exists())						
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"CAMERA_ON");
	}
}
