package Kratos;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class COPE extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"COPE");
	}

	public void testSetUp()
	{	
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Mobiliya Manage");			
			Device.CLICKBYNAME("Mobiliya2", false);
			Device.CLICKBYNAME("Select", true);
			Device.SLEEP(4000);
			Device.CLICKBYNAME("Skip update", true);
			Device.CLICKBYNAME("Accept", true);
			Device.SLEEP(10000);
			Device.CLICKBYNAME("Activate Admin", true);
			Device.CLICKBYNAME("Activate", true);
			Device.SLEEP(3000);
			if("Profile".equals(new UiObject(new UiSelector().resourceId("android:id/action_bar_title")).getText()))
			{
				Device.ADDLOG_MESSAGE("COPE:  Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE("COPE:  Fail");
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"COPE");
	}
}
