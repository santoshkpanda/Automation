package Kratos;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class BYOD extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"BYOD");
	}

	public void testSetUp()
	{		
		try {
			Device.registerAppCrashWatcher();
			/*Device.TURNONWIFI();
			Device.IDLE();*/
			Device.SLEEP(2000);	
			Device.LAUNCHAPPLICATION("Mobiliya Shoonya");
			Device.CLICKBYNAME("Accept", true);
			/*Device.CLICKBYNAME("", false);
			Device.CLICKBYNAME("Select", true);
			Device.SLEEP(4000);
			Device.CLICKBYNAME("Continue without update", true);	
			Device.CLICKBYNAME("Accept", true);*/			
			Device.ENTERTEXTBY_CLASS_INSTANCE("android.widget.EditText", "jalsa.fashion@gmail.com", 0, false);
			Device.ENTERTEXTBY_CLASS_INSTANCE("android.widget.EditText", "n", 1, false);
			Device.BACK();
			Device.CLICKBYNAME("Continue", true);			
			Device.SLEEP(5000);				
			getUiDevice().pressDPadDown();
			new UiObject(new UiSelector().className("android.widget.EditText").instance(2)).setText("jalsa@524A");
			Device.BACK();
			Device.SLEEP(2000);
			Device.CLICKBYDESCRIPTION("Login", true);			
			Device.SLEEP(4000);
			Device.CLICKBYNAME("Activate Admin", true);
			Device.CLICKBYNAME("Activate", true);
			
			
			if("jalsa.fashion".equals((new UiObject(new UiSelector().resourceId("net.agreeyamobility.kratos.service:id/policy_activity_user_name")).getText()))
					|| "jalsa.fashion".equals(Device.GETTEXTBY_CLASS_INSTANCE("android.widget.TextView",1)))				
				Device.ADDLOG_MESSAGE("BYOD:pass");
			else
				Device.ADDLOG_MESSAGE("BYOD:  fail");
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		
		Device.ADDLOG_MESSAGE("End: "+"BYOD");
		Device.HOME();
	}
}
