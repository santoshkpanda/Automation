package Kratos;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class KdmClientUnInstallation extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"KdmClientUnInstallation");
	}

	public void testKDMClientunInstall() {
		try {
			
			boolean ele=Device.LAUNCHAPPLICATIONUNINSTALL("Mobiliya Shoonya");
			Device.IDLE();
			
			if(ele)
			{
			Device.registerAppCrashWatcher();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Security",false,true);
			Device.CLICKLISTVIEWITEM("Device administrators", false,true);
			Device.CLICKBYNAME("Mobiliya Shoonya",true);
			Device.CLICKBYNAME("Deactivate", true);
			Device.SLEEP(1000);
			Device.BACK();
			Device.BACK();
			//Device.CLICKLISTVIEWITEM("Apps",false,true);
			Device.CLICKLISTVIEWITEM("Mobiliya Shoonya",false,true);
			Device.CLICKBYNAME("Uninstall", true);
			Device.CLICKBYNAME("OK", true);
			if (!Device.CHECKAPPLICATION("Mobiliya Shoonya")) {
				System.out.println("Pass");
				Device.ADDLOG_MESSAGE(getName()
						+ " pass Mobiliya Manage Successfully Uninstalled");
			} else {
				System.out.println("Fail");
				Device.ADDLOG_MESSAGE(getName()
						+ " Mobiliya Manage not Uninstalled");
			}
			}
			else
			{
				System.out.println("Mobiliya shoonya is not installed. Please install it ");
			}
				 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Skip");
			Device.ADDLOG_MESSAGE(getName() + " Skipped due to exception");
		}

	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"KdmClientUnInstallation");
	}
}
