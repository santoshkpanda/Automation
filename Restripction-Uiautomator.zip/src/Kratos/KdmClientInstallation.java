package Kratos;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class KdmClientInstallation extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"KdmClientInstallation");
	}
	public void testSetUp()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();		
		try {			
			
			boolean ele=Device.LAUNCHAPPLICATIONUNINSTALL("Mobiliya Shoonya");
			Device.IDLE();
			
			if(!ele)
			{
			
			
			Device.LAUNCHAPPLICATION("ES File Explorer");
			UiObject sdcard=new UiObject(new UiSelector().text("sdcard0"));
			
			sdcard.click();
			Device.CLICKLISTVIEWITEM("MobiliyaShoonya_v80_release_production.apk", false,true);
			/*Device.CLICKBYNAMECONTAINS("Mobiliya", true);
			Device.CLICKBYNAMECONTAINS("Shoonya", true);
			*/
			UiObject installbtn=new UiObject(new UiSelector().text("Install"));
			installbtn.click();
			
			while(new UiObject(new UiSelector().text("Next")).exists())
				Device.CLICKBYNAME("Next", false);
			Device.CLICKBYNAME("Install", true);
			Device.SLEEP(4000);
			Device.CLICKBYNAME("Accept", true);
			Device.SLEEP(4000);
			Device.CLICKBYNAME("Done", false);
			Device.IDLE();
			if(!Device.CHECKAPPLICATION("Mobiliya Shoonya"))
			{
				Device.ADDLOG_MESSAGE("Installation:  Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE("Installation:  Fail");
				System.out.println("Fail");
			}
			}
			else
			{
				System.out.println("Mobiliya shoonya is already present in the device ");
				
			}
			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"KdmClientInstallation");
	}
}
