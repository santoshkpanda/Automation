package Kratos;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class SwitchUser extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"SwitchUser");
	}
	
	public void testSelectPolicyOne()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Mobiliya Manage");
			Device.SLEEP(3000);
			Device.CLICKBYNAME("Continue without update", true);
			Device.CLICKBYDESCRIPTION("Login", true);
			Device.CLICKBYCLASS("android.widget.Spinner", 0, false);
			Device.CLICKBYCLASS("android.widget.CheckedTextView", 0, false);
			Device.CLICKBYNAME("Continue", true);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void testSelectPolicyTwo()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Mobiliya Manage");
			Device.SLEEP(3000);
			Device.CLICKBYNAME("Continue without update", true);
			Device.CLICKBYDESCRIPTION("Login", true);
			Device.CLICKBYCLASS("android.widget.Spinner", 0, false);
			Device.CLICKBYCLASS("android.widget.CheckedTextView", 1, false);
			Device.CLICKBYNAME("Continue", true);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void testSelectPolicyThree()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Mobiliya Manage");
			Device.SLEEP(3000);
			Device.CLICKBYNAME("Continue without update", true);
			Device.CLICKBYDESCRIPTION("Login", true);
			Device.CLICKBYCLASS("android.widget.Spinner", 0, false);
			Device.CLICKBYCLASS("android.widget.CheckedTextView", 2, false);
			Device.CLICKBYNAME("Continue", true);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"SwitchUser");
	}
}
