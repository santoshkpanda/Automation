package ScreenCapture;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class ScreenCaptureOff extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"ScreenCaptureOff");
	}
	public void testScreenCaptureOFF()
	{
		Device.IDLE();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
		Date date = new Date();
		Device.SCREENSHOT("ScreenCaptureOff_"+dateFormat.format(date));
		Device.ADDLOG_MESSAGE(getName()+": Screenshot captured and stored @ sdcard with ScreenCaptureOff.png");
		System.out.println("Screenshot");
		
		
			Device.HOME();
	
		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"ScreenCaptureOff");
	}
}
