package ScreenCapture;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

import uiautomatorApis.Device;

public class ScreenCaptureOn extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"ScreenCaptureOn");
	}
	public void testScreenCaptureOn()
	{
		Device.IDLE();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
		Date date = new Date();
		Device.SCREENSHOT("ScreenCaptureOn_"+dateFormat.format(date));
		Device.ADDLOG_MESSAGE(getName()+": Screenshot captured and stored @ sdcard with ScreenCaptureOn_"+dateFormat.format(date)+".png");
		System.out.println("Screenshot");
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"ScreenCaptureOn");
	}
}
