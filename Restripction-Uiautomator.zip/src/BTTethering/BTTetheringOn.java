package BTTethering;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class BTTetheringOn extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"BTTetheringOn");
	}
	public void testBtTetheringOn()
	{
		Device.registerAppCrashWatcher();
		Device.TURNONWIFI();
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAMECONTAINS("More", true);
			Device.CLICKBYNAMECONTAINS("Tethering", true);
			if(Device.CHECKBOXONOFFSTATUS(2))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.CHECKBOXONOFF(true, 2);
				Device.SLEEP(3000);
				if(Device.CHECKBOXONOFFSTATUS(2))
				{
					Device.ADDLOG_MESSAGE(getName()+"	Pass");
					System.out.println("Pass");
				}
				else
				{
					Device.ADDLOG_MESSAGE(getName()+"	Fail");
					System.out.println("Fail");
				}
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"BTTetheringOn");
	}
}
