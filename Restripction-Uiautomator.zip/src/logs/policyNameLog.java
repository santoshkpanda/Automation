package logs;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class policyNameLog extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"policyNameLog");
	}
	public void testPrintLog()
	{
		String logMessage = getParams().getString("stringKey");
		Device.ADDLOG_MESSAGE(logMessage);
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"policyNameLog");
	}
}
