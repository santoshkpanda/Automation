package lockScreen;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class lock extends UiAutomatorTestCase{
	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"lock");
	}
	
	public void testLockDevice()
	{
		Device.registerAppCrashWatcher();		
		Device.LOCK();
	}	
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"lock");
	}
}
