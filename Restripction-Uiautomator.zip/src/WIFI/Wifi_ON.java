package WIFI;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Wifi_ON extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Wifi_ON");
	}
	
	public void testWifiOn()
	{
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYRESID_INST("Wi-Fi",true);
			Device.SWITCHONOFF(true, 0);
			Device.SLEEP(10000);
			if(new UiObject(new UiSelector().className("android.widget.Switch")).isChecked())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
			
		} catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}	
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Wifi_ON");
	}
}
