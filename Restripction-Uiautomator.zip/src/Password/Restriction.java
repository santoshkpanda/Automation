package Password;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Restriction extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Restriction");
	}

	public void testPasswordRestriction()
	{
		Device.registerAppCrashWatcher();
		Device.CLICKBYNAME("Password", true);
		Device.ENTERTEXTBYRESID("com.android.settings:id/password_entry", "qwerty123", false);
		Device.CLICKBYNAME("Continue", true);
		Device.ENTERTEXTBYRESID("com.android.settings:id/password_entry", "qwerty123", false);
		Device.CLICKBYNAME("OK", true);
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Security",false,true);
			if("Password".equals(Device.GETTEXTBYRESID_INSTANCE("android:id/summary", 0)))
				Device.ADDLOG_MESSAGE("Password Policy Applied Successfully: Pass");
			else
				Device.ADDLOG_MESSAGE("Password Policy Didn't Apply: Fail");
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Restriction");
	}
}
