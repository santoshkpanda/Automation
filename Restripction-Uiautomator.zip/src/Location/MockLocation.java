package Location;
//package Attendance;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class MockLocation extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Verify Mock location");
	}

	public void testmanualAttendance()
	{
		Device.registerAppCrashWatcher();
		try
		{
		Device.LAUNCHAPPLICATION("Settings");
		Device.CLICKLISTVIEWITEM("Developer options", false,true);
		Device.CLICKLISTVIEWITEM("Allow mock locations", false,true);
		Device.CLICKBYRESID("android:id/button1",true);
		Device.IDLE();
		sleep(4000);
		Device.SWIPEDOWN_NOTIFICATIONBAR();
		
		String strIn=new UiObject(new UiSelector().text("Disable mock location")).getText();
		Device.ADDLOG_MESSAGE(strIn);
		if(strIn.contains("mock location"))
		{
			Device.ADDLOG_MESSAGE(getName()+"	Pass");
			System.out.println("Pass");
		}
		
	else
	{
		Device.ADDLOG_MESSAGE(getName()+"	Fail");
		System.out.println("Fail");
	}			
		Device.HOME();
		
		
			}
		catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			Device.ADDLOG_MESSAGE("installation skipped due to execution");
			
			e.printStackTrace();
		}
		finally
		{
			Device.HOME();
		}
		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Mock Location Verify");
	}
	
	
	

}
