package Location;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class SetMockLocation extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Verify Mock location");
	}

	public void testmanualAttendance()
	{
		Device.registerAppCrashWatcher();
		try
		{
		Device.LAUNCHAPPLICATION("Fake Location");
		//Device.CLICKBYRESID("com.fakegps.mock:id/search_button",false)
		Device.CLICKBYRESID("com.fakegps.mock:id/start_btn",true);
		Device.IDLE();
		
		
		}
		catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			Device.ADDLOG_MESSAGE("installation skipped due to execution");
			
			e.printStackTrace();
		}
		finally
		{
			Device.HOME();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Mock Location set");
	}
		
		

}
