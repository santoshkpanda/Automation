package Wallpaper;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class WallpaperOFF extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"WallpaperOFF");
	}

	public void testWallpaperOff() throws UiObjectNotFoundException {
		Device.registerAppCrashWatcher();
		Device.IDLE();
		String beforeOFF="BeforeWallpaperOFF";
		Device.SCREENSHOT(beforeOFF);
		Device.LAUNCHAPPLICATION("Settings");
		Device.CLICKBYNAME("Display", true);
		Device.CLICKBYNAME("Wallpaper", true);
		Device.CLICKBYNAME("Live Wallpapers",true);
		Device.CLICKBYNAME("Phase Beam",true);
		Device.SLEEP(1000);
		Device.CLICKBYNAME("Set wallpaper",true);
		Device.IDLE();
		String AfterWallpaperOFF="AfterWallpaperOFF";
		Device.SCREENSHOT(AfterWallpaperOFF);
		Device.ADDLOG_MESSAGE(getName()+"Please check into the Storage Manually");
		System.out.println("Please check into the Storage Manually");
	}
	
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"WallpaperOFF");
	}
}
