package NFC;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class NFC_ON extends UiAutomatorTestCase{	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"NFC_ON");
	}

	public void testNFCON()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYCLASS("android.widget.TextView", 5, true);
			if(!Device.CHECKBOXONOFFSTATUS(1))
				Device.CHECKBOXONOFF(true, 1);
			Device.SLEEP(2000);
			if(Device.CHECKBOXONOFFSTATUS(1))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}	
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"NFC_ON");
	}
}
