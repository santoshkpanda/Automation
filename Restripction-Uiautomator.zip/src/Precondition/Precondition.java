package Precondition;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;
import uiautomatorApis.Device;

public class Precondition extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Precondition");
	}

	public void testPrecondition() {
		try {
			Device.registerAppCrashWatcher();
			Device.IDLE();
			// Setting the Sleep time=30 minute
			Device.LAUNCHAPPLICATION("Settings");
			// Click on Display
			Device.CLICKBYNAME("Display", true);
			// Sleep
			Device.CLICKBYNAME("Sleep", true);
			// Select 30 minute
			Device.CLICKBYNAMECONTAINS("30 m", false);
			if (new UiObject(new UiSelector().textContains("30 m")).exists())
			{
				System.out.println("Sleep Time set as 30 minute");
				Device.ADDLOG_MESSAGE(getName()+" Sleep Time set as 30 minute");
			}
			else
			{
				System.out.println("Please set sleep time as 30 minute");
				Device.ADDLOG_MESSAGE(getName()+" Please set sleep time as 30 minute");
			}
			
			/*Device.IDLE();
			// Turn ONN WIFI
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYCLASS("android.widget.RelativeLayout", 0, true);
			Device.SWITCHONOFF(true, 0);
			Device.SLEEP(4000);
			while(true)
			{
				if (!new UiObject(new UiSelector().text("Connected")).exists()) {
					Device.CLICKLISTVIEWITEM("Guest1",false,true);
					if (new UiObject(new UiSelector().text("Forget")).exists()) {
						Device.CLICKBYNAME("Forget", true);
						Device.CLICKBYNAME("AgreeYa", true);
					} else {
						Device.ENTERTEXTBYCLASS("android.widget.EditText",
								"1234567890", false);
						Device.SLEEP(3000);
//						Device.BACK();
						Device.CLICKBYNAME("Connect", true);
						Device.SLEEP(15000);
					}
				}
				if (new UiObject(new UiSelector().text("Connected")).exists()) {
					System.out.println("Wi-fi connected");
					Device.ADDLOG_MESSAGE(getName()+" Wi-fi connected");
					break;
				} else {
					System.out.println("Please check Wi-Fi connection");
					Device.ADDLOG_MESSAGE(getName()+" Please check Wi-Fi connection");
				}
			}*/
			// Check whether downloads has KDMClient
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Downloads");
			boolean found=false;
			if (new UiObject(new UiSelector().className(
					"android.widget.TextView").textStartsWith("KDM")).exists()) {
				System.out.println("KDM Client Exist");
				Device.ADDLOG_MESSAGE(getName()+" KDM client exist");
				found=true;
			} else {
				System.out.println("Please Download the KDM Client in Device");
				Device.ADDLOG_MESSAGE(getName()+" Please Download the KDM Client in Device");
			}
			while(!found)
			{
				System.out.println("Please Download the KDM Client in Device");
				Device.ADDLOG_MESSAGE(getName()+" Please Download the KDM Client in Device");
			}
			Device.IDLE();
			// Check unkown sources Under security
			Device.LAUNCHAPPLICATION("Settings");
			UiScrollable secutiry = new UiScrollable(
					new UiSelector().scrollable(true));
			secutiry.scrollTextIntoView("Security");
			Device.CLICKBYNAME("Security", true);
			UiScrollable unknown = new UiScrollable(
					new UiSelector().scrollable(true));
			unknown.scrollTextIntoView("Unknown sources");

			if (!Device.CHECKBOXONOFFSTATUS(1)) {
				Device.CLICKBYNAME("Unknown sources", true);
				Device.CLICKBYNAME("OK", true);
				System.out
						.println("Checked from Allow APP from UNknown sources");
				Device.ADDLOG_MESSAGE(getName()+" Checked from Allow APP from UNknown sources");
			} else {
				System.out
						.println("Already checked for Allow APP from Unlnown Sources");
				Device.ADDLOG_MESSAGE(getName()+" Already checked for Allow APP from Unlnown Sources");
			}
			Device.IDLE();

		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Precondition");
	}

}
