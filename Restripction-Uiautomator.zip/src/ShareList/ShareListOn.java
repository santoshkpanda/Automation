package ShareList;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class ShareListOn extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"ShareListOn");
	}
	public void testShareListOn()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Camera");
			new UiObject(new UiSelector().packageName("com.google.android.gallery3d")).swipeLeft(3);
			Device.CLICKBYDESCRIPTION("Share with", true);
			if(new UiObject(new UiSelector().text("Bluetooth")).exists())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"ShareListOn");
	}
}
