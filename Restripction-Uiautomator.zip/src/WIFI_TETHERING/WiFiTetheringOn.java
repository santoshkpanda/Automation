package WIFI_TETHERING;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class WiFiTetheringOn  extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"WiFiTetheringOn");
	}
	

	public void testWifiTetheringOn()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			//Device.CLICKBYNAME("More...", true);
			Device.CLICKBYCLASS("android.widget.TextView", 5, true);
			Device.CLICKBYNAMECONTAINS("Tethering", true);
			if(!Device.CHECKBOXONOFFSTATUS(1))
				Device.CHECKBOXONOFF(true, 1);
			Device.SLEEP(5000);			
			if(Device.CHECKBOXONOFFSTATUS(1))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
			
		} catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"WiFiTetheringOn");
	}
}
