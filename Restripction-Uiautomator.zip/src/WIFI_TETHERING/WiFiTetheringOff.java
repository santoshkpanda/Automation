package WIFI_TETHERING;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class WiFiTetheringOff extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"WiFiTetheringOff");
	}

	public void testWifiTetheringOFF()
	{
		try {
			Device.registerAppCrashWatcher();
			/*Device.TURNONWIFI();
			Device.IDLE();*/
			Device.LAUNCHAPPLICATION("Settings");
			//Device.CLICKBYNAME("More...", true);
			Device.CLICKBYCLASS("android.widget.TextView", 6, true);
			Device.CLICKBYNAMECONTAINS("Tethering", true);
			if(!new UiObject(new UiSelector().className("android.widget.Switch")).isChecked())
				new UiObject(new UiSelector().className("android.widget.Switch")).click();
			Device.SLEEP(10000);
			
			if(!new UiObject(new UiSelector().className("android.widget.Switch")).isChecked())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
			
		} catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}	
		finally
		{
			Device.HOME();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"WiFiTetheringOff");
	}
}
