package VideoRecording;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class VideoRecordingOn extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"VideoRecordingOn");
	}
	public void testVideoRecordingOn()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Camera");
			Device.CLICKBYDESCRIPTION("Camera, video, or panorama selector", false);
			Device.CLICKBYDESCRIPTION("Switch to video", false);
			Device.CLICKBYDESCRIPTION("Shutter button", false);			
			//validation pending
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"VideoRecordingOn");
	}
}
