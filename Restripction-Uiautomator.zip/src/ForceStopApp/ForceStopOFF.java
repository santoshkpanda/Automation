package ForceStopApp;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class ForceStopOFF extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"ForceStopOFF");
	}

	private static final UiDevice UiDevice = null;

	public void testForceStopAppOff() {
		try{
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Apps", false, true);
			UiObject launcher = new UiObject(
					new UiSelector().packageName("com.android.settings"));
			launcher.swipeLeft(100);
			Device.SLEEP(2000);
			launcher.swipeLeft(100);
			Device.SLEEP(2000);
			Device.CLICKLISTVIEWITEM("Android Live Wallpapers", false, true);
			if (!new UiObject(new UiSelector().className("android.widget.Button").instance(0)).isEnabled()) {
				Device.ADDLOG_MESSAGE(getName()
						+ " App force stop option disabled : Pass");
				System.out.println(" App force stop option disabled : Pass");
			} else {
				Device.ADDLOG_MESSAGE(getName()
						+ "  App force stop option enabled : Fail");
				System.out.println("  App force stop option enabled : Fail");
			}
		} catch(Exception e){
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
			e.printStackTrace();
		}
		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"ForceStopOFF");
	}

}
