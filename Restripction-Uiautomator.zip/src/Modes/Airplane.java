package Modes;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Airplane extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Airplane");
	}
	
	public void testAirplaneOff()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAMECONTAINS("More", true);
			Device.CHECKBOXONOFF(true, 0);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void testAirplaneOn()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAMECONTAINS("More", true);
			Device.CHECKBOXONOFF(false, 0);			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Airplane");
	}
}
