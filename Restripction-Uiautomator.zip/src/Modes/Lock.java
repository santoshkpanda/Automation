package Modes;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Lock extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Lock");
	}
	
	public void testLock()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		Device.LOCK();		
	}
	
	public void testUnlock()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		Device.UNLOCK();			
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Lock");
	}
}
