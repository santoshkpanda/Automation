package HomeKey;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class HomeKeyOFF extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"HomeKeyOFF");
	}

	public void testHomeKeyOff()
	{
		try{
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.HOME();
			if (new UiObject(new UiSelector().text("Settings")).exists()) {
				Device.ADDLOG_MESSAGE(getName()+" Home key is restricted : Pass");
				System.out.println("Home key is restricted : Pass");
			} else {
				Device.ADDLOG_MESSAGE(getName()+" Home key is not restricted : Fail");
				System.out.println("Home key is not restricted : Fail");
			}
		} catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"HomeKeyOFF");
	}
}
