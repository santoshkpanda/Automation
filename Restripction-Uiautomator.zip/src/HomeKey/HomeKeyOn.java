package HomeKey;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

import uiautomatorApis.Device;

public class HomeKeyOn extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"HomeKeyOn");
	}
	public void testHomeKeyOn()
	{
		try{
			Device.registerAppCrashWatcher();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.HOME();
			if(new UiObject(new UiSelector().text("Settings")).exists())
			{
				 Device.ADDLOG_MESSAGE("Home key is restricted : Fail");
				 System.out.println("Home key is restricted : Fail");
			}	
			else
			{
				Device.ADDLOG_MESSAGE("Home key is not restricted : Pass");
				System.out.println("Home key is not restricted : Pass");
			}
		}catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"HomeKeyOn");
	}

}
