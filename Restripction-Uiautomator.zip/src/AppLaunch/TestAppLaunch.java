package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class TestAppLaunch extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"TestAppLaunch");
	}

	public void testAppLaunch()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		String appName = getParams().getString("stringKey");
		try {
			appName=appName.replaceAll("-", " ");
			Device.ADDLOG_MESSAGE(appName);
			boolean hasLaunched=Device.LAUNCHAPPLICATION(appName);
			if(hasLaunched)
			{
				Device.ADDLOG_MESSAGE(appName+" App Launched : Fail");
				System.out.println("Fail");
			}
			else
			{
				Device.ADDLOG_MESSAGE(appName+" App Not Launched : Pass");
				System.out.println("Pass");
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"TestAppLaunch");
	}
}
