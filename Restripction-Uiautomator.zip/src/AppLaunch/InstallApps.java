package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class InstallApps extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"InstallApps");
	}
	
	public void testInstallApp()
	{
		String appName = getParams().getString("stringKey");
		//String appName2="Twitter";
		Device.registerAppCrashWatcher();
		Device.IDLE();		
		//try {			
			Device.SWIPEDOWN_NOTIFICATIONBAR();
			while(new UiObject(new UiSelector().textContains("Downloading")).exists())
				Device.SLEEP(2000);
			
			//appName=appName.replaceAll("-", " ");
			
			//Device.SLEEP(10000);
			Device.CLICKBYNAMECONTAINS(appName, true);
			Device.SLEEP(3000);
			while(new UiObject(new UiSelector().text("Next")).exists())
				Device.CLICKBYNAME("Next", false);
			Device.CLICKBYNAME("Install", true);
			Device.SLEEP(30000);
			//Device.CLICKBYNAME("Done", false);	
			
			boolean hasAppPresent=new UiObject(new UiSelector().text("Done")).exists();
			Device.IDLE();
			//boolean hasAppPresent=Device.LAUNCHAPPLICATION(appName2);
			if(hasAppPresent)
			{
				Device.ADDLOG_MESSAGE(appName+" App got installed : Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(appName+" App didn't get install : Fail");
				System.out.println("Fail");
			}
		
		/* catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			Device.ADDLOG_MESSAGE("installation skipped due to execution");
			
			e.printStackTrace();
		}*/
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"InstallApps");
		Device.HOME();
	}
}
