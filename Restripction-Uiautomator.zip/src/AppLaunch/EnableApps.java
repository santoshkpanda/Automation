package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class EnableApps extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"EnableApps");
	}
	public void testEnableApp()
	{
		/*Device.IDLE();
		String appName = getParams().getString("stringKey");
		appName=appName.replaceAll("-", " ");
		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Apps",false,true);
			UiObject launcher = new UiObject(new UiSelector().packageName("com.android.settings"));
			launcher.swipeLeft(100);
			Device.SLEEP(2000);
			launcher.swipeLeft(100);
			Device.SLEEP(4000);
			Device.CLICKLISTVIEWITEM(appName,false,true);		
			if(new UiObject(new UiSelector().text("Disable")).exists())
			{
				System.out.println("Pass");
				Device.ADDLOG_MESSAGE(appName+" App got enabled : Pass");
			}
			else
			{
				System.out.println("Fail");
				Device.ADDLOG_MESSAGE(appName+" App got disabled : Fail");
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			String appName = getParams().getString("stringKey");
			appName=appName.replaceAll("-", " ");
			Device.LAUNCHAPPLICATION(appName);
			Device.SLEEP(4000);
			Device.SCREENSHOT("Enable_"+appName);
			Device.ADDLOG_MESSAGE(appName+" App got Enabled  : Please check screenshot");
			System.out.println("Screenshot");
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"EnableApps");
	}
}
