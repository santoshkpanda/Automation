package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Blacklist extends UiAutomatorTestCase{
	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Blacklist");
	}
	public void testBlacklistApp()
	{
		/*Device.IDLE();
		String appName = getParams().getString("stringKey");
		try {
			appName=appName.replaceAll("-", " ");
			Device.LAUNCHAPPLICATION(appName);			
			Device.ENTERTEXTBYCLASS("android.widget.EditText", "uiautomator", false);
			Device.ENTER();
			Device.SLEEP(2000);
			if(new UiObject(new UiSelector().resourceId("com.android.chrome:id/tab_switcher_button")).exists())
				Device.ADDLOG_MESSAGE("Search done");
			else
				Device.ADDLOG_MESSAGE("Search not done");
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/		
		try {
			Device.registerAppCrashWatcher();
			/*Device.TURNONWIFI();
			Device.IDLE();		*/	
			String appName = getParams().getString("stringKey");
			appName=appName.replaceAll("-", " ");
			Device.LAUNCHAPPLICATION(appName);
			Device.SLEEP(4000);
			Device.SCREENSHOT("Blacklist_"+appName);
			Device.ADDLOG_MESSAGE(appName+" App got blacklisted : Please check screenshot");
			//System.out.println("Screenshot");
			boolean bool=true;
			
			if (bool)
			{

				//System.out.println("Audio Volume is set as Zero level!!!!");
				System.out.println("this test case pass ho gaya");
				Device.ADDLOG_MESSAGE(getName()+"Pass");
				System.out.println("Pass");

			} else {
				//System.out.println("Audio Volume is set as Some Positive Value!!!");
				System.out.println("this test case is fail");
				Device.ADDLOG_MESSAGE(getName()+"Fail");
				System.out.println("Fail");
			}		
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
		finally
		{
			Device.HOME();
		}
		
			
		/*} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Blacklist");
		Device.HOME();
	}
}
