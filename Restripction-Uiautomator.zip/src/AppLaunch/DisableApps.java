package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class DisableApps extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"DisableApps");
	}
	public void testDisableApp()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			String appName = getParams().getString("stringKey");
			appName=appName.replaceAll("-", " ");
			Device.LAUNCHAPPLICATION(appName);
			Device.SLEEP(4000);
			Device.SCREENSHOT("Disable_"+appName);
			Device.ADDLOG_MESSAGE(appName+" App got disabled  : Please check screenshot");
			System.out.println("Screenshot");
			
//			Device.CLICKLISTVIEWITEM("Apps");
//			UiObject launcher = new UiObject(new UiSelector().packageName("com.android.settings"));
//			launcher.swipeLeft(100);
//			Device.SLEEP(2000);
//			launcher.swipeLeft(100);
//			Device.SLEEP(2000);
//			Device.CLICKLISTVIEWITEM(appName);			
//			if(new UiObject(new UiSelector().text("Disable")).exists())
//				Device.ADDLOG_MESSAGE(appName+" App got disabled : Pass");
//			else
//				Device.ADDLOG_MESSAGE(appName+" App got enabled : Fail");
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"DisableApps");
	}
}

