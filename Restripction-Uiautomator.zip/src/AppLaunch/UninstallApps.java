package AppLaunch;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class UninstallApps extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"UninstallApps");
	}
	public void testUninstallApp()
	{
		Device.registerAppCrashWatcher();
		Device.IDLE();
		String appName = getParams().getString("stringKey");
		appName=appName.replaceAll("-", " ");
		try {			
			Device.SWIPEDOWN_NOTIFICATIONBAR();
			while(!new UiObject(new UiSelector().text("Uninstalling")).exists())
				Device.SLEEP(2000);			
			Device.CLICKBYNAMECONTAINS("Uninstall", true);
			Device.CLICKBYNAME("OK", true);
			Device.SLEEP(5000);
			Device.IDLE();
			boolean hasAppPresent=Device.LAUNCHAPPLICATION(appName);
			if(!hasAppPresent)
			{
				System.out.println("Pass");
				Device.ADDLOG_MESSAGE(appName+" App got uninstalled : Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(appName+" App didn't get uninstall : Fail");
				System.out.println("Fail");
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
/*		try {
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Apps");
			UiObject launcher = new UiObject(new UiSelector().packageName("com.android.settings"));
			launcher.swipeLeft(100);
			Device.SLEEP(2000);
			launcher.swipeLeft(100);
			Device.SLEEP(2000);
			Device.CLICKLISTVIEWITEM(appName);
			Device.CLICKBYNAME("Uninstall", true);
			Device.CLICKBYNAME("OK", true);
			Device.IDLE();
			boolean hasAppPresent=Device.LAUNCHAPPLICATION(appName);
			if(hasAppPresent)
				Device.ADDLOG_MESSAGE(appName+" App Didn't uninstall : Fail");
			else
				Device.ADDLOG_MESSAGE(appName+" App got uninstalled : Pass");
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"UninstallApps");
	}
}
