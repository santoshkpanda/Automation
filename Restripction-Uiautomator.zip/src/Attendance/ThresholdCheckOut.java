package Attendance;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class ThresholdCheckOut extends UiAutomatorTestCase{
	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Manual Atendance");
	}

	public void testmanualAttendance()
	{
		Device.registerAppCrashWatcher();
		
		try {
		
			Device.SWIPEDOWN_NOTIFICATIONBAR();
			//new UiObject(new UiSelector().textContains("reminder")).click();
			Device.CLICKBYNAMECONTAINS("reminder", true);
			
			sleep(4000);
			/*Device.CLICKBYDESCRIPTION("Settings",true);
			Device.CLICKBYRESID("net.agreeyamobility.kratos.service:id/action_image",false);
			Device.BACK();
			*/
			Device.CLICKBYRESID("net.agreeyamobility.kratos.service:id/policy_checkin_checkout", true);
			
			String strIn=new UiObject(new UiSelector().resourceId("net.agreeyamobility.kratos.service:id/attendance_dialog_time")).getText();
			
			Device.ADDLOG_MESSAGE(strIn);
			Device.CLICKBYRESID("net.agreeyamobility.kratos.service:id/dialog_ok_btn",true);
			
			Device.SWIPEDOWN_NOTIFICATIONBAR();
			
			if(!(new UiObject(new UiSelector().textContains("reminder")).exists()))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			
		else
		{
			Device.ADDLOG_MESSAGE(getName()+"	Fail");
			System.out.println("Fail");
		}			
			
			
			
		}
		catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}	
		finally
		{
			Device.HOME();
		}
	}
		public void tearDown(){
			Device.ADDLOG_MESSAGE("End: "+"Restriction");
		}
}
	
