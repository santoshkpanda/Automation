package Device;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Note extends UiAutomatorTestCase {
	public void setUp() {
		Device.ADDLOG_MESSAGE("Start: " + "Note");
	}

	public void testOpenNote()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("ColorNote");
			Device.CLICKBYCLASS("android.widget.ImageButton", 0, true);
			Device.CLICKBYCLASS("android.widget.TextView", 1, true);
            new UiObject(new UiSelector().className("android.widget.EditText").instance(1)).setText("Testing text");
            for(int i=1;i<4;i++){
            Device.BACK();
            }
            Device.HOME();
            Device.LAUNCHAPPLICATION("ColorNote");
           
            if(new UiObject(new UiSelector().className("android.widget.TextView").textContains("Testing text")) != null)
            {
            	Device.ADDLOG_MESSAGE(getName()+"	Pass");
            	System.out.println("Note IS created");
            	
            }
            else{
            	Device.ADDLOG_MESSAGE(getName()+"	Fail");
            	System.out.println("Note IS not  created");
            	
            }
           
            

		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Note");
	}

}
