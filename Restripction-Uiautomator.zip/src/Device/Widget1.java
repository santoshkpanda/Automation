package Device;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Widget1 extends UiAutomatorTestCase {
	public void setUp() {
		Device.ADDLOG_MESSAGE("Start: " + " Widget1");
	}
	
	public void testWidget1() throws UiObjectNotFoundException
	{
			Device.IDLE();
			UiDevice.getInstance().pressMenu();
			Device.SLEEP(3000);
			Device.CLICKBYNAME("Widgets", true);
			Device.SLEEP(1000);
			new UiObject(new UiSelector().className("android.widget.ImageView").description("Analog clock")).longClick();
			Device.SLEEP(2000);
			Device.CLICKBYCLASS("android.view.View", 1, true);
			
			
			
		
	  
       
		
		
		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Widget1");
	}

}
