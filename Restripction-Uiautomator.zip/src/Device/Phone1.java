package Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

import uiautomatorApis.Device;

public class Phone1 extends UiAutomatorTestCase {
	
	public void setUp() {
		Device.ADDLOG_MESSAGE("Start: " + "Phone1");
	}
	public void testPhonecall()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Phone");
			Device.CLICKBYDESCRIPTION("More options", true);
			Device.CLICKBYNAME("New contact", true);
			Device.CLICKBYNAME("Phone contact",true);
			new UiObject(new UiSelector().className("android.widget.EditText").text("Name")).setText("Abhishek");
			new UiObject(new UiSelector().className("android.widget.EditText").text("Phone")).setText("1234567");
			Device.CLICKBYNAME("Done", true);
			Device.SLEEP(2000);
			if(new UiObject(new UiSelector().className("android.widget.TextView").text("Abhishek")).exists()){
				
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Contacts is Created!!!");
				
				}
			else{
				
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Contacts is't created!!!");
				
			}
			
			} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Phone1");
	}

}
