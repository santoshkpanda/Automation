package Device;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Phone2 extends UiAutomatorTestCase {
	
	public void setUp() {
		Device.ADDLOG_MESSAGE("Start: " + "Phone2");
	}
	public void testPhoneLog()
	{
		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Phone");
			Device.CLICKBYDESCRIPTION("dial pad", true);
			Device.CLICKBYNAME("1", false);
			Device.CLICKBYNAME("2", false);
			Device.CLICKBYNAME("3", false);
			Device.CLICKBYDESCRIPTION("Dial",false );
			Device.CLICKBYNAME("OK", false);
			Device.CLICKBYDESCRIPTION("Call History", true);
			if(!new UiObject(new UiSelector().className("android.widget.TextView").text("Call log is empty.")).exists()){
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Call log is visible!!!");
				
				}
			else{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Call Log is't Visible!!!");
				
			}
			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Phone2");
	}
	

}
