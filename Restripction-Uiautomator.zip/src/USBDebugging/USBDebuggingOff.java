package USBDebugging;

import uiautomatorApis.Device;

import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class USBDebuggingOff extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"USBDebuggingOff");
	}
	public void testUSBDebuggingOff()
	{		
		try {
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();
			Device.LAUNCHAPPLICATION("Settings");
			Device.CLICKLISTVIEWITEM("Developer options",false,true);
			if(!Device.CHECKBOXONOFFSTATUS(2))
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}		
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"USBDebuggingOff");
	}
}
