package StatusBar;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class StatusBarOff  extends UiAutomatorTestCase{	
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"StatusBarOff");
	}

	public void testStatusBarOFF()
	{
		try{
			Device.registerAppCrashWatcher();
			Device.TURNONWIFI();
			Device.IDLE();		
			Device.SWIPEDOWN_NOTIFICATIONBAR();		
			if(!new UiObject(new UiSelector().resourceId("com.android.systemui:id/date")).exists())
			{
				Device.ADDLOG_MESSAGE(getName()+"	Pass");
				System.out.println("Pass");
			}
			else
			{
				Device.ADDLOG_MESSAGE(getName()+"	Fail");
				System.out.println("Fail");
			}
		}catch(Exception e){
			e.printStackTrace();
			Device.ADDLOG_MESSAGE(getName()+"	Skip");
			System.out.println("Skip");
		}
	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"StatusBarOff");
	}
}
