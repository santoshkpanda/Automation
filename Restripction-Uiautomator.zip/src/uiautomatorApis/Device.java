package uiautomatorApis;

import java.io.BufferedWriter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.graphics.Rect;
import android.os.RemoteException;
import android.view.KeyEvent;

import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiScrollable;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.core.UiWatcher;

public class Device {
	private static final String VoicenSmsOff = null;
	static UiDevice device = UiDevice.getInstance();
	static Date date = null;
	private static String OK_BUTTON_WATCHER = "appCrashDialogWatcher";
	private static String CONTACTS_WATCHER = "keepLocalButtonWatcher";
	static int passCount=0;
	static int failCount=0;
	static int skipCount=0;
	
	public static void ADDLOG_MESSAGE(final String message)
	{		
//		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-ddHHmmss");
//		Date date = new Date();
//		String fileName = "/mnt/sdcard/Results" + dateFormat.format(date) + ".txt";
		String fileName = "/mnt/sdcard/UiAutomator_logs10.txt";
		File file = new File(fileName);
		try 
		{
			if(!file.exists())
				file.createNewFile();
			FileWriter writer = new FileWriter(file,true);
			BufferedWriter bw = new BufferedWriter(writer);			
			bw.write("["+ GETCURRENTDATE_TIME()+ "] " + message + "\n");
			
			if(message.toUpperCase().contains("PASS"))
			{	
				passCount++;
				bw.write(message);
				bw.write("test case passed");
				bw.write("the value of test-pass count is :"+passCount);
				
			}	
			else if(message.toUpperCase().contains("FAIL"))
			{
				failCount++;
				bw.write(message);
				bw.write("test case failed");
				bw.write("the value of test-fail count is :"+failCount);
				
				//bw.write(failCount);
			}
			
			else if (message.toUpperCase().contains("SKIP"))
			{
				skipCount++;
				bw.write(message);
				bw.write("test case skipped");
				bw.write("the value of test-skip count is :"+skipCount);
				
				//bw.write(skipCount);
		
			}
			
			/*else
			{
				bw.write(message);
				bw.write("test case skipped");
			}*/
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
			
			
			
		}
		
	}
	
	public static void ADDRESULTCOUNT()
	{
		ADDLOG_MESSAGE("Total Pass: "+passCount+"Total Fail: "+failCount);
	}
	
	public static String GETCURRENTDATE_TIME() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public static void BACK()
	{		
		device.pressBack();	
	}	
	
	public static void HOME()
	{
		device.pressHome();
	}
	
	public static void RECENTAPPS()
	{
		try {
			device.pressRecentApps();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void ENTER()
	{
		device.pressKeyCode(66);
	}
	
	public static boolean VOLUME_UP()
	{
		boolean hasVolumeUp = device.pressKeyCode(KeyEvent.KEYCODE_VOLUME_UP);
		ADDLOG_MESSAGE("I_VOLUME_UP: " + hasVolumeUp);
		return hasVolumeUp;	
	}
	
	public static boolean VOLUME_DOWN()
	{
		boolean hasVolumeDown = device.pressKeyCode(KeyEvent.KEYCODE_VOLUME_DOWN);
		ADDLOG_MESSAGE("I_VOLUME_DOWN: " + hasVolumeDown);
		return hasVolumeDown;		
	}	
	public static void IDLE()
	{
		for(int i=0;i<5;i++)
			device.pressBack();
	}
	
	public static void UNLOCK()
	{
		try {
			device.wakeUp();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			new UiObject(new UiSelector().description("Slide area.")).dragTo(new UiObject(new UiSelector().className("android.widget.FrameLayout")), 5);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void LOCK()
	{
		try {
			device.sleep();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void WAKEUP()
	{
		try {
			device.wakeUp();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void SLEEP(int time)
	{
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/*public static boolean LAUNCHAPPLICATION(String appName) throws UiObjectNotFoundException
	{
		boolean hasAppLaunched = false;
		UiObject allAppsButton = new UiObject(new UiSelector().description("Apps"));
		allAppsButton.clickAndWaitForNewWindow();
		if(new UiObject(new UiSelector().text("Widgets")).exists())
		{	
			ADDLOG_MESSAGE("In first if loop widgets");
			new UiObject(new UiSelector().text("Widgets")).click();
			
		}	
		if(new UiObject(new UiSelector().text("Apps")).exists())
		{
			ADDLOG_MESSAGE("In second if loop apps");
			UiObject appsTab = new UiObject(new UiSelector().text("Apps"));	
			appsTab.click();
			
		}
		UiObject launcher;
		UiObject App;
		if(new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")).exists())
		{
			ADDLOG_MESSAGE("In google quick search box if loop");
			launcher = new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")); 
			App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
			launcher.swipeRight(100);
			
			SLEEP(2000);
		} else{
			ADDLOG_MESSAGE("In else block of google quick search box");
			launcher = new UiObject(new UiSelector().packageName("^(com.android.launcher).*$"));
			ADDLOG_MESSAGE("able to find launcher");
			
			String str=(launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName))).getText();
			ADDLOG_MESSAGE("able to find twitter app aslo");
			ADDLOG_MESSAGE("app name is"+str);
			
			App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
			
			
			//String str=App.getText();
			ADDLOG_MESSAGE("able to find text of app name");
			//ADDLOG_MESSAGE("name of the app is"+str);
		}		
		for(int i = 0; i < 5; i++)
		{
			ADDLOG_MESSAGE("Entered for loop");
			if(!(App.exists()))
			{
				ADDLOG_MESSAGE("In first if loop of for loop");
				launcher.swipeLeft(100);
				
			}
			if(App.exists())
			{
				ADDLOG_MESSAGE("In last if loop of for loop");
				hasAppLaunched = App.clickAndWaitForNewWindow();
				//hasAppLaunched=true;
				//SLEEP(3000);
				break;
				
			}
		}
		ADDLOG_MESSAGE("Application Launched: "+appName+" "+hasAppLaunched);
	    return hasAppLaunched;
	}*/

	public static boolean LAUNCHAPPLICATIONUNINSTALL(String appName) 

			throws UiObjectNotFoundException
				{
					boolean hasAppLaunched = false;
					UiObject allAppsButton = new UiObject(new UiSelector().description("Apps"));
					allAppsButton.clickAndWaitForNewWindow();
					if(new UiObject(new UiSelector().text("Widgets")).exists())
						new UiObject(new UiSelector().text("Widgets")).click();			
					if(new UiObject(new UiSelector().text("Apps")).exists())
					{
						UiObject appsTab = new UiObject(new UiSelector().text("Apps"));	
						appsTab.click();
					}
					UiObject launcher;
					UiObject App;
					if(new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")).exists())
					{
						launcher = new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")); 
						App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
						launcher.swipeRight(100);
						
						SLEEP(2000);
					} 
					else
					{
						launcher = new UiObject(new UiSelector().packageNameMatches("^(com.android.launcher).*$")); 
						App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
					}		
					for(int i = 0; i < 5; i++)
					{
						if(!(App.exists()))
						{
							launcher.swipeLeft(100);
						}
						if(App.exists())
						{
							//hasAppLaunched = App.clickAndWaitForNewWindow();
							hasAppLaunched=true;
							break;
						}
					}
					ADDLOG_MESSAGE("Application Launched: "+appName+" "+hasAppLaunched);
				    return hasAppLaunched;
				}
	public static boolean LAUNCHAPPLICATION(String appName) 

			throws UiObjectNotFoundException
				{
					boolean hasAppLaunched = false;
					UiObject allAppsButton = new UiObject(new UiSelector().description("Apps"));
					allAppsButton.clickAndWaitForNewWindow();
					if(new UiObject(new UiSelector().text("Widgets")).exists())
						new UiObject(new UiSelector().text("Widgets")).click();			
					if(new UiObject(new UiSelector().text("Apps")).exists())
					{
						UiObject appsTab = new UiObject(new UiSelector().text("Apps"));	
						appsTab.click();
					}
					UiObject launcher;
					UiObject App;
					if(new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")).exists())
					{
						launcher = new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")); 
						App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
						launcher.swipeRight(100);
						
						SLEEP(2000);
					} 
					else
					{
						launcher = new UiObject(new UiSelector().packageNameMatches("^(com.android.launcher).*$")); 
						App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
					}		
					for(int i = 0; i < 5; i++)
					{
						if(!(App.exists()))
						{
							launcher.swipeLeft(100);
						}
						if(App.exists())
						{
							hasAppLaunched = App.clickAndWaitForNewWindow();
							break;
						}
					}
					ADDLOG_MESSAGE("Application Launched: "+appName+" "+hasAppLaunched);
				    return hasAppLaunched;
				}
	public static boolean LAUNCHAPPLICATION_ALL(String message) throws UiObjectNotFoundException
	{
		boolean hasAppLaunched = true;
		UiObject allAppsButton = new UiObject(new UiSelector().description("Apps"));
		allAppsButton.clickAndWaitForNewWindow();
		if(new UiObject(new UiSelector().text("Widgets")).exists())
			new UiObject(new UiSelector().text("Widgets")).click();			
		if(new UiObject(new UiSelector().text("Apps")).exists())
		{
			UiObject appsTab = new UiObject(new UiSelector().text("Apps"));	
			appsTab.click();
		}
		
		
			Integer appCount=new UiObject(new UiSelector().className("android.view.View").instance(2)).getChildCount();
			System.out.println("Total Apps: "+ appCount);			
			for (int i = 0; i < appCount; i++) {
				IDLE();
				allAppsButton.clickAndWaitForNewWindow();
				CLICKBYCLASS("android.widget.TextView", i, true);
				SLEEP(5000);
				String VoicenSms = message + "_"+i;
				SCREENSHOT(VoicenSms);	
			}
			
			return hasAppLaunched;
}

	public static boolean CHECKAPPLICATION(String appName) throws UiObjectNotFoundException
	{
		boolean hasAppExists = false;
		/*UiObject allAppsButton = new UiObject(new UiSelector().description("Apps"));
		allAppsButton.clickAndWaitForNewWindow();
		if(new UiObject(new UiSelector().text("Widgets")).exists())
			new UiObject(new UiSelector().text("Widgets")).click();			
		if(new UiObject(new UiSelector().text("Apps")).exists())
		{
			UiObject appsTab = new UiObject(new UiSelector().text("Apps"));	
			appsTab.click();
		}
		UiObject launcher;
		UiObject App;
		if(new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")).exists())
		{
			launcher = new UiObject(new UiSelector().packageName("com.google.android.googlequicksearchbox")); 
			App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
			launcher.swipeRight(100);
			SLEEP(2000);
		} else{
			//launcher = new UiObject(new UiSelector().packageNameMatches("^(com.android.launcher).*$")); 
			//launcher = new UiObject(new UiSelector().packageNameMatches("com.android.launcher3")); 
			launcher = new UiObject(new UiSelector().packageName("com.android.launcher3")); 
			App = launcher.getChild(new UiSelector().className("android.widget.TextView").text(appName));
		}
		for(int i = 0; i < 5; i++)
		{			
			if(!(App.exists()))
			{
				launcher.swipeLeft(100);
			}
			if(App.exists())
			{
				hasAppExists = true;
				break;
			}
		}
		ADDLOG_MESSAGE("Application Present: "+appName+" "+hasAppExists);*/
	    return hasAppExists;
	}
	
	
	public static void SWIPEDOWN_NOTIFICATIONBAR() 
	{
		try 
		{
			if(!device.isScreenOn())
			{
				device.wakeUp();	
			}
			int dHeight = device.getDisplayHeight();
		    int dWidth = device.getDisplayWidth();
		    int xScrollPosition = dWidth/2;
		    int yScrollStop = dHeight/2;
		   
		  boolean hasSwipe=device.swipe(xScrollPosition, 0, xScrollPosition, yScrollStop, 10);
		  ADDLOG_MESSAGE("swipeDownNotificationBar: " + hasSwipe);
		  SLEEP(3000);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		   
	}
	
	public static boolean CLICKLISTVIEWITEMUNINSTALL(String name,boolean isHScroll,boolean isScrollable) throws UiObjectNotFoundException 
	{
		UiScrollable listView = new UiScrollable(new UiSelector().scrollable(isScrollable));		 			 
		 if(isHScroll)
			 listView.setAsHorizontalList();
		 else
			 listView.setAsVerticalList();	 
		 listView.scrollToBeginning(0);
		 listView.scrollTextIntoView(name);
		 listView.waitForExists(5000);
		 UiObject listViewItem = listView.getChild(new UiSelector().text(name));
		 boolean ele=listViewItem.exists();
		 return ele;
    }
	
	public static boolean CLICKLISTVIEWITEM(String name,boolean isHScroll,boolean isScrollable) throws UiObjectNotFoundException 
	{
		 UiScrollable listView = new UiScrollable(new UiSelector().scrollable(isScrollable));		 			 
		 if(isHScroll)
			 listView.setAsHorizontalList();
		 else
			 listView.setAsVerticalList();	 
		 listView.scrollToBeginning(0);
		 listView.scrollTextIntoView(name);
		 listView.waitForExists(5000);
		 UiObject listViewItem = listView.getChild(new UiSelector().text(name));
		 boolean hasListItemClick = listViewItem.clickAndWaitForNewWindow();
//		 ADDLOG_MESSAGE("I_CLICKLISTVIEWITEM: " + name +": " + hasListItemClick);
		 return hasListItemClick;
    }
	public static boolean CLICKBYNAME(String objName,boolean waitForNewWindow)
	{
		boolean hasClickByName = false;
		try {
			UiObject object = new UiObject(new UiSelector().text(objName));
			if(waitForNewWindow)
				hasClickByName = object.clickAndWaitForNewWindow();
			else
				hasClickByName = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByName = false;
		}
		ADDLOG_MESSAGE("CLICKBYNAME: "+objName+" "+hasClickByName);
		return hasClickByName;		
	}
	
	public static boolean CLICKBYRESID(String objName,boolean waitForNewWindow)
	{
		boolean hasClickByResId = false;
		try {
			UiObject object = new UiObject(new UiSelector().resourceId(objName));
			if(waitForNewWindow)
				hasClickByResId = object.clickAndWaitForNewWindow();
			else
				hasClickByResId = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByResId = false;
		}
		ADDLOG_MESSAGE("CLICKBYID: "+objName+" "+hasClickByResId);
		return hasClickByResId;		
	}
	
	public static boolean CLICKBYNAMECONTAINS(String objName,boolean waitForNewWindow)
	{
		boolean hasClickByName = false;
		try {
			UiObject object = new UiObject(new UiSelector().textContains(objName));
			if(waitForNewWindow)
				hasClickByName = object.clickAndWaitForNewWindow();
			else
				hasClickByName = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByName = false;
		}	
		ADDLOG_MESSAGE("CLICKBYNAMECONTAINS: "+objName+" "+hasClickByName);
		return hasClickByName;		
	}
	
	public static boolean CLICKBYDESCRIPTION(String desc, boolean waitForNewWindow)
	{
		boolean hasClickByDesc = false;
		try {
			UiObject object  = new UiObject(new UiSelector().description(desc));
			if(waitForNewWindow)
				hasClickByDesc = object.clickAndWaitForNewWindow();
			else
				hasClickByDesc = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByDesc = false;
		}	
		ADDLOG_MESSAGE("CLICKBYDESCRIPTION: "+desc+" "+hasClickByDesc);
		return hasClickByDesc;
	}
	
	public static boolean CLICKBYDESCRIPTIONCONTAINS(String desc, boolean waitForNewWindow)
	{
		boolean hasClickByDesc = false;
		try {
			UiObject object  = new UiObject(new UiSelector().descriptionContains(desc));
			if(waitForNewWindow)
				hasClickByDesc = object.clickAndWaitForNewWindow();
			else
				hasClickByDesc = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByDesc = false;
		}		
		return hasClickByDesc;		
	}
	
	public static boolean ENTERTEXTBYCLASS(String className, String enterText, boolean hasToClear)
	{
		boolean hasTextEnteredbyClass = false;
		try {
			UiObject object = new UiObject(new UiSelector().className(className));
			if(hasToClear)
				object.clearTextField();
			hasTextEnteredbyClass = object.setText(enterText);
		} catch (UiObjectNotFoundException e) {
			hasTextEnteredbyClass = false;
		}	
		ADDLOG_MESSAGE("ENTERTEXTBYCLASS: "+className+" "+hasTextEnteredbyClass);
		return hasTextEnteredbyClass;
	}
	
	public static boolean ENTERTEXTBYRESID(String resId, String enterText, boolean hasToClear)
	{
		boolean hasTextEnteredbyResid = false;
		try {
			UiObject object = new UiObject(new UiSelector().resourceId(resId));
			if(hasToClear)
				object.clearTextField();
			hasTextEnteredbyResid = object.setText(enterText);
		} catch (UiObjectNotFoundException e) {
			hasTextEnteredbyResid = false;
		}
		ADDLOG_MESSAGE("ENTERTEXTBYRESID: "+resId+" "+hasTextEnteredbyResid);
		return hasTextEnteredbyResid;
	}
	
	public static boolean ENTERTEXTBYDESC(String desc, String enterText, boolean hasToClear)
	{
		boolean hasTextEnteredbyDesc = false;
		try {
			UiObject object = new UiObject(new UiSelector().description(desc));
			if(hasToClear)
				object.clearTextField();
			hasTextEnteredbyDesc = object.setText(enterText);
		} catch (UiObjectNotFoundException e) {
			hasTextEnteredbyDesc = false;
		}
		ADDLOG_MESSAGE("ENTERTEXTBYDESC: "+desc+" "+hasTextEnteredbyDesc);
		return hasTextEnteredbyDesc;
	}
	
	public static boolean ENTERTEXTBYRESID_INSTANCE(String resId , String enterText, int instnce,  boolean hasToClear)
 	{
 		boolean hasTextEnteredbyResId=false; 		
 		try {
 			UiObject object = new UiObject(new UiSelector().resourceId(resId).instance(instnce));
 			if(hasToClear)
				object.clearTextField();
 			hasTextEnteredbyResId = object.setText(enterText); 			
 		} catch (UiObjectNotFoundException e) {
 			 hasTextEnteredbyResId=false;
 		}
 		ADDLOG_MESSAGE("ENTERTEXTBYRESID_INSTANCE: "+resId+" "+hasTextEnteredbyResId);
 		return  hasTextEnteredbyResId;		
 	}
	
	public static boolean ENTERTEXTBY_CLASS_INSTANCE(String className , String enterText, int instnce,  boolean hasToClear)
 	{
 		boolean hasTextEnteredbyClass=false; 		
 		try {
 			UiObject object = new UiObject(new UiSelector().className(className).instance(instnce));
 			if(hasToClear)
				object.clearTextField();
 			hasTextEnteredbyClass = object.setText(enterText); 			
 		} catch (UiObjectNotFoundException e) {
 			 hasTextEnteredbyClass=false;
 		}
 		ADDLOG_MESSAGE("ENTERTEXTBY_CLASS_INSTANCE: "+className+" "+hasTextEnteredbyClass);
 		return  hasTextEnteredbyClass;		
 	}
	
	public static String GETTEXTBY_CLASS_INSTANCE(String className, int instnce)
 	{
 		boolean hasTextByClass=false;
 		String text="";
 		try {
 			UiObject object = new UiObject(new UiSelector().className(className).instance(instnce));			
 			text = object.getText();
 			if(text!=null)
 				hasTextByClass=true;
 		} catch (UiObjectNotFoundException e) {
 			 hasTextByClass=false;
 		}
 		ADDLOG_MESSAGE("GETTEXTBY_CLASS_INSTANCE: "+text+" "+hasTextByClass);
 		return  text;		
 	}
	
	public static String GETTEXTBYRESID_INSTANCE(String resId, int instnce)
 	{
 		boolean hasTextByRes=false;
 		String text="";
 		try {
 			UiObject object = new UiObject(new UiSelector().resourceId(resId).instance(instnce));			
 			text = object.getText();
 			if(text!=null)
 				hasTextByRes=true;
 		} catch (UiObjectNotFoundException e) {
 			 hasTextByRes=false;
 		}
 		ADDLOG_MESSAGE("GETTEXTBYRESID_INSTANCE: "+text+" "+hasTextByRes);
 		return  text;		
 	}
	
	public static String GETDESCBY_CLASS(String className, int inst)
 	{
 		boolean hasDescByRes=false;
 		String desc="";
 		try {
 			UiObject object = new UiObject(new UiSelector().className(className).instance(inst));			
 			desc = object.getContentDescription(); 			
 			if(desc!=null)
 				hasDescByRes=true;
 		} catch (UiObjectNotFoundException e) {
 			 hasDescByRes=false;
 		}
 		ADDLOG_MESSAGE("GETDESCBY_CLASS: "+desc+" "+hasDescByRes);
 		return  desc;
 	}
	
	public static boolean CHECKBOXONOFF(boolean falseorTrue, int inst) throws UiObjectNotFoundException 
	{
		/*boolean hasChecked=false;
		UiObject object = new UiObject(new UiSelector().className("android.widget.CheckBox").instance(inst));
		if(falseorTrue)
		{
			if(!object.isChecked())
			{
				try {
					hasChecked = object.click();
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			}
			else
				hasChecked = true;
		}
		else
		{
			
		
			if(!object.isChecked())
			{
				try {
					hasChecked = object.click();
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			}
			else
				hasChecked = true;
		}
		ADDLOG_MESSAGE("CHECKBOXONOFF: "+falseorTrue+" "+hasChecked);
		return hasChecked;*/
		
		
		boolean hasChecked=false;
		UiObject object = new UiObject(new UiSelector().className("android.widget.CheckBox").instance(inst));
		
			/*if(!object.isChecked())
			{
				try {
					hasChecked = object.click();
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			}
			else
				hasChecked = true;
		}
		else
		{
			
		
			if(!object.isChecked())
			{
		*/		try {
					hasChecked = object.click();
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			/*}
			else*/
				hasChecked = true;
		
		ADDLOG_MESSAGE("CHECKBOXONOFF: "+falseorTrue+" "+hasChecked);
		return hasChecked;
	}
	
	public static boolean CHECKBOXONOFFSTATUS(int inst) throws UiObjectNotFoundException 
	{
		boolean hasChecked=false;
		UiObject object = new UiObject(new UiSelector().className("android.widget.CheckBox").instance(inst));
		if(object.isChecked())
		{			
			hasChecked = true;		
		}
		ADDLOG_MESSAGE("CHECKBOXONOFFSTATUS: "+inst+" "+hasChecked);
		return hasChecked;
	}
	public static boolean CLICKBYCLASS(String objName, int inst,boolean waitForNewWindow)
	{
		boolean hasClickByClass = false;
		try {
			UiObject object = new UiObject(new UiSelector().className(objName).instance(inst));
			if(waitForNewWindow)
				hasClickByClass = object.clickAndWaitForNewWindow();
			else
				hasClickByClass = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByClass = false;
		}
		ADDLOG_MESSAGE("CLICKBYCLASS: "+objName+" "+hasClickByClass);
		return hasClickByClass;		
	}
	
	public static boolean CLICKBYRESID_INST(String objName, boolean waitForNewWindow)
	{
		boolean hasClickByResid = false;
		try {
			UiObject object = new UiObject(new UiSelector().text(objName));
			if(waitForNewWindow)
				hasClickByResid = object.clickAndWaitForNewWindow();
			else
				hasClickByResid = object.click();
		} catch (UiObjectNotFoundException e) {
			hasClickByResid = false;
		}
		ADDLOG_MESSAGE("CLICKBYRESID_INST: "+objName+" "+hasClickByResid);
		return hasClickByResid;		
	}
	public static boolean SWITCHONOFF(boolean falseorTrue, int inst) throws UiObjectNotFoundException 
	{
		boolean hasChecked=false;
		UiObject object = new UiObject(new UiSelector().className("android.widget.Switch").instance(inst));
		if(falseorTrue)
		{
			if(!object.isChecked())
			{
				try {
					object.click();
					hasChecked = object.isChecked();
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			}
			else
				hasChecked = true;
		}
		else
		{
			if(object.isChecked())
			{
				try {
					object.click();
					hasChecked = !(object.isChecked());
				} catch (UiObjectNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					hasChecked = false;
				}
			}
			else
				hasChecked = true;
		}
		ADDLOG_MESSAGE("SWITCHONOFF: "+falseorTrue+" "+hasChecked);
		return hasChecked;
	}
	
	public static boolean TURNONWIFI()
	{
		boolean hasTurnedOn=false;
		try {
			IDLE();
			LAUNCHAPPLICATION("Settings");
			hasTurnedOn=SWITCHONOFF(true, 0);			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return hasTurnedOn;		
	}
	
	public static boolean TURNOFFWIFI()
	{
		boolean hasTurnedOff=false;
		try {
			IDLE();
			LAUNCHAPPLICATION("Settings");
			hasTurnedOff=SWITCHONOFF(false, 0);			
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return hasTurnedOff;		
	}
	
	public static boolean TURNONDATA()
	{
		boolean hasTurnedOn=false;
		try {
			IDLE();
			LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAMECONTAINS("More", true);
			Device.CLICKBYNAME("Mobile networks", true);
			hasTurnedOn=CHECKBOXONOFF(true, 0);		
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return hasTurnedOn;		
	}
	
	public static boolean TURNOFFDATA()
	{
		boolean hasTurnedOff=false;
		try {
			IDLE();
			LAUNCHAPPLICATION("Settings");
			Device.CLICKBYNAMECONTAINS("More", true);
			Device.CLICKBYNAME("Mobile networks", true);
			hasTurnedOff=CHECKBOXONOFF(false, 0);		
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return hasTurnedOff;		
	}
	
	public static boolean STATUSBAR()
	{
		boolean hasNotification=false;
		UiObject notification=new UiObject(new UiSelector().resourceId("com.android.launcher:id/drag_layer"));
		try {
		  	hasNotification=notification.swipeDown(5);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ADDLOG_MESSAGE("STATUSBAR: "+" "+hasNotification);
	  	return hasNotification;
	 }
	
	public static void SCREENSHOT(String filename) 
	{
//		boolean hasScreenshot=false;
//		File storePath = new File("/mnt/sdcard/"+filename);
//		hasScreenshot = device.takeScreenshot(storePath);
//		return hasScreenshot;
		Process process;
        try {
            process = Runtime.getRuntime().exec(
                    "screencap -p " + "/mnt/sdcard/"+filename+".png");
            process.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	}
	
	public static UiWatcher okButtonWatcher = new UiWatcher() {

		public boolean checkForCondition() {

			UiObject okCancelDialog = new UiObject(
					new UiSelector().textContains("has stopped."));
			if (okCancelDialog.exists()) {
				try {
					UiObject okButton = new UiObject(new UiSelector()
							.className("android.widget.Button").text("OK"));

					okButton.clickAndWaitForNewWindow();
				} catch (UiObjectNotFoundException e) {
					e.printStackTrace();
				}
				return (okCancelDialog.waitUntilGone(25000));
			}
			return false;
		}
	};
	
	public static void registerKeepLocalButtonWatcher(){
		device.registerWatcher(CONTACTS_WATCHER,
				keepLocalButtonWatcher);
		device.runWatchers();
	}
	
	public static UiWatcher keepLocalButtonWatcher = new UiWatcher() {
		public boolean checkForCondition() {
			UiObject okCancelDialog = new UiObject(
					new UiSelector().textContains("Keep local"));
			if (okCancelDialog.exists()) {
				try {
					UiObject keepLocalButton = new UiObject(new UiSelector()
							.className("android.widget.Button").text("Keep local"));
					keepLocalButton.clickAndWaitForNewWindow();
				} catch (UiObjectNotFoundException e) {
					e.printStackTrace();
				}
				return (okCancelDialog.waitUntilGone(25000));
			}
			return false;
		}
	};
	
	public static void registerAppCrashWatcher(){
		device.registerWatcher(OK_BUTTON_WATCHER,
				okButtonWatcher);
		device.runWatchers();
	}	
	
	public static boolean scrollToBeginning()
	{
		boolean hasScrolled = false;
		UiScrollable scrollable = new UiScrollable(new UiSelector().scrollable(true));
	    try {
			 hasScrolled = scrollable.scrollToEnd(1, 3);
//	    	scrollable.scrollToBeginning(1, 3);
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block			
			e.printStackTrace();
			return false;
		}
	    ADDLOG_MESSAGE("scrollToBeginning:" + hasScrolled);
		return hasScrolled;
	}
	
	public static boolean VSCROLL_DOWN()
	{
		boolean hasScrolledToDown = false;
		UiScrollable listView = new UiScrollable(new UiSelector().scrollable(true));
		listView.setAsVerticalList();
		try {
			hasScrolledToDown = listView.scrollToEnd(10);
		} catch (UiObjectNotFoundException e) {
			hasScrolledToDown = false;
		}
		ADDLOG_MESSAGE("VSCROLL_DOWN:" + hasScrolledToDown);
		return hasScrolledToDown;
	}
	
	public static boolean VSCROLL_TOP()
	{
		boolean hasScrolledToTop = false;
		UiScrollable listView = new UiScrollable(new UiSelector().scrollable(true));
		listView.setAsVerticalList();
		try {
			hasScrolledToTop = listView.scrollToBeginning(10);
		} catch (UiObjectNotFoundException e) {
			hasScrolledToTop = false;
		}
		ADDLOG_MESSAGE("VSCROLL_TOP " + hasScrolledToTop);
		return hasScrolledToTop;
	}
	
	public static boolean SETLANDSCAPE()
    {           
          try {
                device.setOrientationNatural();
                return true;
          } catch (RemoteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return false;
          }
    }
    
    public static boolean SETPORTRAIT()
    {           
          try {
                device.setOrientationLeft();               
                return true;
          } catch (RemoteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                return false;
          }
    }
	
    public static boolean OPTION()
    {           
    	boolean hasMenu=false;
    	hasMenu=device.pressMenu();
    	Device.ADDLOG_MESSAGE("Menu Option: "+hasMenu);
    	return hasMenu;
    }
}
