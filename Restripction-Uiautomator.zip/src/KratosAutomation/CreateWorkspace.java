package KratosAutomation;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;
import uiautomatorApis.Device;
public class CreateWorkspace extends UiAutomatorTestCase {
	
	public void test001() {
		// precondition
		//Utils.unlockDevice(getUiDevice());Add the case.
        Device.HOME();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			
		} catch (UiObjectNotFoundException e) {
			System.out.println("Setting app not found");
		}
        // Click Security option
		Device.CLICKBYNAME("Security", true);
		// Click Kratos option
		Device.CLICKBYNAME("Kratos",true);
		// validation
		//check if activate button is present and enabled.
		
		UiObject activateOption = new UiObject(new UiSelector().className(
				"android.widget.RelativeLayout").index(1));
		try {
			activateOption.getText();
			
			if(activateOption.isClickable() && activateOption.isEnabled()){
			//validation passes
				
				//ktc.setTestCaseStatus(true);
			}else{
				//Validation fails here
				//ktc.setTestCaseStatus(false);
			}
			
		} catch (UiObjectNotFoundException e) {
			//Validation fails here 
			//ktc.setTestCaseStatus(false);			
		}

		try {
			activateOption.clickAndWaitForNewWindow();
			System.out.println("Workspace added");
		} catch (UiObjectNotFoundException e) {
			e.printStackTrace();
		}

	}

	public void test002() {

		       //Device.IDLE();
		       System.out.println("<<<<Now Entering the Pin>>>>");
		       // Select Android Device Manager
				Device.CLICKBYNAME("Pin",true);
		        System.out.println("Entering pin 1111");
				// Enter Pin
				UiObject txtPin1 = new UiObject(new UiSelector().className(
						"android.widget.EditText").index(1));

				try {
					txtPin1.clearTextField();
					txtPin1.setText("1111");
					Device.BACK();
					} 
				 catch (UiObjectNotFoundException e) {
					e.printStackTrace();
				}
				
				// Enter Confirm Pin
				UiObject txtPin2 = new UiObject(new UiSelector().className(
						"android.widget.EditText").index(2));

				try {
					txtPin2.clearTextField();
					txtPin2.setText("1111");
					getUiDevice().pressBack();
					
				} catch (UiObjectNotFoundException e) {
					e.printStackTrace();
				}
				
				// Click "Create" button
				Device.CLICKBYNAME("Create", true);
				sleep(2000);
				//Here testcase passed
				System.out.println("Workspace configured");
				    Device.HOME();
					UiObject okBtn=new UiObject(new UiSelector().text("OK").className("android.widget.Button"));
					try {
						okBtn.click();
						
						} catch (UiObjectNotFoundException e) {
						e.printStackTrace();
						}
					
					UiObject allAppsButton = new UiObject(
							new UiSelector().className("android.widget.TextView").index(1));
					try {
						allAppsButton.click();
					} catch (UiObjectNotFoundException e) {
						e.printStackTrace();
					}
					Device.SLEEP(2000);
					okBtn =  new UiObject(new UiSelector().text("OK").className("android.widget.Button"));
					try {
						okBtn.click();
						
						} catch (UiObjectNotFoundException e) {
						e.printStackTrace();
						
					}
			}
}
