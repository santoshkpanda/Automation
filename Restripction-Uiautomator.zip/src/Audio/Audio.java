package Audio;

import uiautomatorApis.Device;

import android.os.RemoteException;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class Audio extends UiAutomatorTestCase{
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"Audio");
	}
	
	public void SetAudio() throws UiObjectNotFoundException, RemoteException {
		
		
					Device.IDLE();
					Device.LAUNCHAPPLICATION("Settings");
					UiObject audioprfl = new UiObject(new UiSelector().className("android.widget.TextView").text("Audio profiles"));
					audioprfl.clickAndWaitForNewWindow(); 
					UiObject general = new UiObject(new UiSelector().className("android.widget.ImageView").description("Device settings"));
					general.clickAndWaitForNewWindow();
					UiObject volumes = new UiObject(new UiSelector().className("android.widget.TextView").text("Volumes"));
					volumes.clickAndWaitForNewWindow();
					Device.SLEEP(5);
					Device.HOME();
					//Swipe Notification Down
					Device.SWIPEDOWN_NOTIFICATIONBAR();
					
					if(new UiObject(new UiSelector().description("Ringer vibrate.")).exists())
					{
						
						System.out.println("Audio Volume is set as Zero level!!!!");
						Device.ADDLOG_MESSAGE(getName()+" Pass");
						
						
					}
					else{
						System.out.println("Audio Volume is set as Some Positive Value!!!");
						Device.ADDLOG_MESSAGE(getName()+" Fail");
					}
					
					Device.HOME();
					
		}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"Audio");
	}

}
