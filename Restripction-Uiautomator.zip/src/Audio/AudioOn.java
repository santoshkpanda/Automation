package Audio;

import uiautomatorApis.Device;

import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiObjectNotFoundException;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public class AudioOn extends UiAutomatorTestCase {
	public void setUp(){
		Device.ADDLOG_MESSAGE("Start: "+"AudioOn");
	}

	public void testAudioOn() {

		Device.IDLE();
		try {
			Device.LAUNCHAPPLICATION("Settings");
			UiObject audioprfl = new UiObject(new UiSelector().className(
					"android.widget.TextView").text("Audio profiles"));
			audioprfl.clickAndWaitForNewWindow();
			UiObject general = new UiObject(new UiSelector().className(
					"android.widget.ImageView").description("Device settings"));
			general.clickAndWaitForNewWindow();
			UiObject volumes = new UiObject(new UiSelector().className(
					"android.widget.TextView").text("Volumes"));
			volumes.clickAndWaitForNewWindow();
			Device.SLEEP(2000);
			Device.IDLE();
			// Swipe Notification Down
			Device.SWIPEDOWN_NOTIFICATIONBAR();
			Device.SLEEP(2000);
			if (!new UiObject(new UiSelector().descriptionContains("Ringer"))
					.exists()) {
				System.out.println("Audio Volume is set as Some Positive Value!!!");
				Device.ADDLOG_MESSAGE(getName() + " Pass");
			} else {
				System.out.println("Audio Volume is set as Zero level!!!!");
				Device.ADDLOG_MESSAGE(getName() + " Fail");
			}
		} catch (UiObjectNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}
	public void tearDown(){
		Device.ADDLOG_MESSAGE("End: "+"AudioOn");
	}

}
